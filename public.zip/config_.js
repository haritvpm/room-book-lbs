// config.js
// module.exports = {
//     db: {
//         user: 'your_db_user',
//         password: 'your_db_password',
//         connectString: 'localhost/orclpdb1'
//     },
// };



module.exports = {
    db: {
        user: 'root',
        password: 'root',
        connectString: 'localhost/orclpdb1'
    },
};